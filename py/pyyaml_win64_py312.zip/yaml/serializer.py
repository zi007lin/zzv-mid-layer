# Simulated serializer.py
