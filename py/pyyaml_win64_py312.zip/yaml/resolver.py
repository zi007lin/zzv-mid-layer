# Simulated resolver.py
