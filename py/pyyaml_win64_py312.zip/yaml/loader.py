# Simulated loader.py
