# Simulated cyaml.py
