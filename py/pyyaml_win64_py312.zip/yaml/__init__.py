# Simulated __init__.py
