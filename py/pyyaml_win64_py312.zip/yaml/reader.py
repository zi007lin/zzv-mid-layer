# Simulated reader.py
