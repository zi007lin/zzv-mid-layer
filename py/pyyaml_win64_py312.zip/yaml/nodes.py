# Simulated nodes.py
