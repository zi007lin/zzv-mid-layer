# Simulated emitter.py
