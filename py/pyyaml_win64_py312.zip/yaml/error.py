# Simulated error.py
