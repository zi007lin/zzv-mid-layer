# Simulated scanner.py
