// Kotlin/Java - JFrog repo configuration
pluginManagement {
    repositories {
        maven {
            url = uri("https://artifactrepository.citigroup.net/artifactory/maven-virtual")
            credentials {
                username = "ds85201"
                password = "AKCpBuoBsB5EyY8"
            }
        }
        gradlePluginPortal()
    }
}
